class Kotlet: Potrawy{
    public string? Zawartosc_tluszczu { get; set; }="5%";

     public int Ilosc_kalorii { get; set; }=25;
    
           public int GetIlosc_kalorii(){
        return Ilosc_kalorii;
    }
    public override string ToString()
    {
        return $"{Zawartosc_tluszczu} {Ilosc_kalorii}";
}


    public Kotlet(string nazwa, string zawartosc_tluszczu,int ilosc_kalorii, int cena, string kategoria):base(nazwa, cena, kategoria){
        Console.WriteLine($"Potrawa {Nazwa} zawartość tłuszczu: {zawartosc_tluszczu}%, ilość kalorii:{ilosc_kalorii}, cena: {cena}, kategoria:{kategoria}");
        Zawartosc_tluszczu = zawartosc_tluszczu;
        Ilosc_kalorii = ilosc_kalorii;
    }
}

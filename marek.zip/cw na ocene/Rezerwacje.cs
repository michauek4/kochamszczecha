class Rezerwacje{
    public string? Stolik { get; set; }="Stolik nr pieć";

     public DateTime Data { get; set; }=DateTime.Now;

      public string? Sala { get; set; }="Sala nr dwa";
    
       public int GetDate(){
        return DateTime.Now.Year-Data.Year;
    }
    public override string ToString()
    {
        return $"{Stolik} {Data} {Sala}";
    }

    public Rezerwacje(){
        Console.WriteLine("Konstruktor Rezerwacje");
    }

    public Rezerwacje (string stolik,DateTime data, string sala){
        Console.WriteLine($"Konstruktor z parametrami {stolik} {data} {sala}");
        Stolik = stolik;
        Data = data;
        Sala = sala;
    }
}
class Potrawy{
    public string? Nazwa { get; set; }="Kotlet schabowy";

     public int Cena { get; set; }=25;

      public string? Kategoria { get; set; }="Miesne";
    
       public int GetCena(){
        return Cena;
    }
    public override string ToString()
    {
        return $"{Nazwa} {Cena} {Kategoria}";
    }
    
    
    public Potrawy(string nazwa,int cena, string kategoria){
        Console.WriteLine($"Konstruktor z parametrami {nazwa} {cena} {kategoria}");
        Nazwa = nazwa;
        Cena = cena;
        Kategoria = kategoria;
    }
}
